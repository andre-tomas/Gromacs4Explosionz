#include "version.h"
const char _gmx_ver_string[] = "VERSION 4.5.4-20110321-fe29f33-dirty";
const char _gmx_full_git_hash[] = "fe29f33d948b12d5731c1d3e78966523e46943fa-dirty";
const char _gmx_central_base_hash[] = "";
